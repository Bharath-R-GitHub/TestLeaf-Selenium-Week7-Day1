package week7.assignments.day1.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day1.base.BaseClass;
import week7.assignments.day1.page.FindLead;
import week7.assignments.day1.page.MainPage;

public class DeleteLeadTestcase extends BaseClass {

	@BeforeTest
	public void setFileNames() {
		fileName = "DeleteLead";
		sheetName = "DeleteLead";
	}

	@Test(dataProvider = "fetchData")
	public void deleteLeadTest(String phnNumSearch) throws InterruptedException {
		MainPage mp = new MainPage(driver);
		mp.enterUserName("DemoCSR").enterPassword("crmsfa").clickLogin().clickCRMSFA().clickLeads().findLead()
				.clickPhone().enterPhoneNumber(phnNumSearch).clickFindLead();

		FindLead fl = new FindLead(driver);
		String leadID = fl.captureFirstLeadID();
		fl.clickFirstLead().clickDeleteButton().leads().findLead().enterCaptureLeadId(leadID).clickFindLead()
				.validation().leadIDValidation();
	}
}