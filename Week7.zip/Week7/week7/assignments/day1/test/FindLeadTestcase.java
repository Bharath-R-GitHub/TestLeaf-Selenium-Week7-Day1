package week7.assignments.day1.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day1.base.BaseClass;
import week7.assignments.day1.page.FindLead;
import week7.assignments.day1.page.MainPage;

public class FindLeadTestcase extends BaseClass{
	
	@BeforeTest
	public void setFileNames() {
		fileName = "FindLead";
		sheetName = "FindLead";
	}

	@Test(dataProvider = "fetchData")
	public void findLeadTest(String emailSearch) throws InterruptedException {
		MainPage mp = new MainPage(driver);
		mp.enterUserName("DemoCSR").enterPassword("crmsfa").clickLogin().clickCRMSFA().clickLeads().findLead().clickEmail().enterEmailSearch(emailSearch)
		.clickFindLead();
		
		FindLead fl = new FindLead(driver);
		String leadName = fl.captureFirstLead();
		fl.clickFirstLead().clickDuplicateButton().findLeadSubmit().leadNameValidation(leadName);
	}
}
