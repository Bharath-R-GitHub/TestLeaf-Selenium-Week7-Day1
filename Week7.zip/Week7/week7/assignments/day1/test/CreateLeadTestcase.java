package week7.assignments.day1.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day1.base.BaseClass;
import week7.assignments.day1.page.MainPage;

public class CreateLeadTestcase extends BaseClass {

	@BeforeTest
	public void setFileNames() {
		fileName = "CreateLead";
		sheetName = "CreateLead";
	}

	@Test(dataProvider = "fetchData")
	public void createLeadTest(String cName, String fName, String lName, String localFName, String dept, String desc,
			String eMail, String phNum, String state) {
		MainPage mp = new MainPage(driver);
		mp.enterUserName("DemoCSR").enterPassword("crmsfa").clickLogin().clickCRMSFA().clickLeads().clickCreateLead()
				.enterCompanyName(cName).enterFirstName(fName).enterLastName(lName).enterFirstNameLocal(localFName)
				.enterDeptName(dept).enterDesc(desc).enterMail(eMail).enterPhoneNumber(phNum).enterState(state)
				.createLeadValidate().leadValidate(fName);
	}
}
