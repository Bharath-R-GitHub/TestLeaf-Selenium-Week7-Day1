package week7.assignments.day1.base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.assignments.day1.readExcel.ReadExcel;

public class BaseClass {

	public ChromeDriver driver;
	public String fileName;
	public String sheetName;

	@BeforeMethod
	public void preCondition(@Optional("http://leaftaps.com/opentaps/control/main") String url) {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get(url);
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider
	public String[][] fetchData() throws IOException {
		return ReadExcel.readExcelData(fileName, sheetName);
	}
}
