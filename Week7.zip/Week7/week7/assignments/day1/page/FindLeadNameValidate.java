package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import week7.assignments.day1.base.BaseClass;

public class FindLeadNameValidate extends BaseClass {

	public FindLeadNameValidate(ChromeDriver driver) {
		this.driver = driver;
	}

	public void leadNameValidation(String expected) {
		String dupFName = driver.findElement(By.xpath("//span[contains(@id,'firstName')]")).getText();
		String dupLName = driver.findElement(By.xpath("//span[contains(@id,'lastName')]")).getText();
		String actual = dupFName + " " + dupLName;
		Assert.assertEquals(actual, expected);
	}
}
