package week7.assignments.day1.page;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import week7.assignments.day1.base.BaseClass;

public class DeleteLeadValidate extends BaseClass {

	public boolean actual;

	public DeleteLeadValidate(ChromeDriver driver, boolean actual) {
		this.driver = driver;
		this.actual = actual;
	}

	public void leadIDValidation() {
		Assert.assertTrue(actual);
	}
}
