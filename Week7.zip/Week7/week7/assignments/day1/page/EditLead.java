package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class EditLead extends BaseClass{

	public EditLead(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public EditLeadDetails clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditLeadDetails(driver);
	}
}
