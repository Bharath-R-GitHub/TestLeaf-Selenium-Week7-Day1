package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class HomePage extends BaseClass {

	public HomePage(ChromeDriver driver) {
		this.driver = driver;
	}

	public LeadMain clickLeads() {
		driver.findElement(By.linkText("Leads")).click();
		return new LeadMain(driver);
	}

}
