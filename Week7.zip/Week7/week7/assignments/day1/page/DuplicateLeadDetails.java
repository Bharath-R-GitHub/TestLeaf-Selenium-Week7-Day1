package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class DuplicateLeadDetails extends BaseClass {

	public DuplicateLeadDetails(ChromeDriver driver) {
		this.driver = driver;
	}

	public DuplicateLeadDetails enterNewCompanyName(String nCmpName) {
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(nCmpName);
		return this;
	}

	public DuplicateLeadDetails enterNewFirstName(String nFName) {
		driver.findElement(By.id("createLeadForm_firstName")).clear();
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(nFName);
		return this;
	}

	public ViewLead clickCreateDuplicate() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLead(driver);
	}
	
	public FindLeadNameValidate findLeadSubmit() {
		driver.findElement(By.className("smallSubmit")).click();
		return new FindLeadNameValidate(driver);
	}

}
