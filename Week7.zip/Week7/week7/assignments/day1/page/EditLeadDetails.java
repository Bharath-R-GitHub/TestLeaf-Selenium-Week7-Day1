package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class EditLeadDetails extends BaseClass{
	
	public EditLeadDetails(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EditLeadDetails enterImpNote(String impNote) {
		driver.findElement(By.id("updateLeadForm_description")).clear();
		driver.findElement(By.id("updateLeadForm_importantNote")).sendKeys(impNote);
		return this;
	}
	
	public ViewLead clickUpdate() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLead(driver);
	}
}
