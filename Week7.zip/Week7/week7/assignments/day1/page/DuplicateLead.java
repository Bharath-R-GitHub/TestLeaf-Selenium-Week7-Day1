package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class DuplicateLead extends BaseClass {

	public DuplicateLead(ChromeDriver driver) {
		this.driver = driver;
	}

	public DuplicateLeadDetails clickDuplicateButton() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicateLeadDetails(driver);
	}
	
	public DeleteLead clickDeleteButton() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		return new DeleteLead(driver);
	}
}
