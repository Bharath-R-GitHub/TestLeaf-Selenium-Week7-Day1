package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import week7.assignments.day1.base.BaseClass;

public class CreateLead extends BaseClass {

	public CreateLead(ChromeDriver driver) {
		this.driver = driver;
	}

	public CreateLead enterCompanyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}

	public CreateLead enterFirstName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}

	public CreateLead enterLastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}

	public CreateLead enterFirstNameLocal(String fNameLocal) {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(fNameLocal);
		return this;
	}

	public CreateLead enterDeptName(String deptName) {
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(deptName);
		return this;
	}

	public CreateLead enterDesc(String desc) {
		driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);
		return this;
	}

	public CreateLead enterMail(String email) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		return this;
	}
	
	public CreateLead enterPhoneNumber(String phNum) {
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phNum);
		return this;
	}

	public CreateLead enterState(String state) {
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
		return this;
	}
	
	public EditLead editLead() {
		driver.findElement(By.name("submitButton")).click();
		return new EditLead(driver);
	}
	
	public DuplicateLead duplicateLead() {
		driver.findElement(By.name("submitButton")).click();
		return new DuplicateLead(driver);
	}

	public ViewLead createLeadValidate() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLead(driver);
	}
}
