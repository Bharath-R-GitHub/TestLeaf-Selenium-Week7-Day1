package week7.assignments.day1.page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import week7.assignments.day1.base.BaseClass;

public class MainPage extends BaseClass {

	public MainPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public MainPage enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		return this;
	}

	public MainPage enterPassword(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	public LoginPage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new LoginPage(driver);
	}

}
