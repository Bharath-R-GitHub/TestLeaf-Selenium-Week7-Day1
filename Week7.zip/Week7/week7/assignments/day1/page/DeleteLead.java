package week7.assignments.day1.page;

import org.openqa.selenium.chrome.ChromeDriver;

import week7.assignments.day1.base.BaseClass;

public class DeleteLead extends BaseClass{
	
	public DeleteLead(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public LeadMain leads() {
		return new LeadMain(driver);
	}
}
